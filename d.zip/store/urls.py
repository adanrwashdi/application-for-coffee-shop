from django.urls import path
from . import views


urlpatterns = [
    path('checkout/', views.CheckOutView.as_view(), name='CheckOutView'),
    path('cart/', views.CartView.as_view(), name='CartView'),
    path('payment-webhook/', views.WebhookView.as_view(), name='WebhookView'),
]