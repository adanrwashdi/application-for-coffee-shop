import json
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View
from coffee_app.models import Coffee, Order, OrderItem
from django.contrib.auth.models import User

# Create your views here.

class CartView(View):
    def get(self, request):
        # request.session["cart"] = {}
        cart = request.session.get("cart", {})
        data = []
        total_price = 0
        if cart:
            products = Coffee.get_coffee_by_id(cart.keys())
            for product in products:
                quantity = cart.get(str(product.id), None)
                if quantity:
                    product_total = product.price * int(quantity)
                    data.append({
                        "product": product,
                        "quantity": quantity,
                        "total_price": product_total
                    })
                    total_price += product_total
        context = {"data": data, "total_price": total_price}
        return render(request, "store/cart.html", context)

    def post(self, request):
        product_id = request.POST.get('product_id', None)
        action = request.POST.get('action', None)
        cart = request.session.get('cart', {})
        quantity = cart.get(product_id, None)

        if quantity:
            if action == "remove":
                if quantity <= 1:
                    cart.pop(product_id)
                    messages.success(request, "Item Removed")
                else:
                    cart[product_id] = quantity-1
                    messages.success(request, "Quantity Decreased")
            elif action == "add":
                cart[product_id] = quantity+1
                messages.success(request, "Quantity Increased")
            elif action == "delete":
                cart.pop(product_id)
                messages.success(request, "Item Removed")
        else:
            cart[product_id] = 1
            messages.success(request, "Added to cart successfully.")

        request.session['cart'] = cart
        
        print('cart', request.session['cart'])
        previous_url = request.META['HTTP_REFERER'] 
        if previous_url:
            return redirect(previous_url)
        return redirect('store:HomeView')



class CartView(View):
    def get(self, request):
        # request.session["cart"] = {}
        cart = request.session.get("cart", {})
        data = []
        total_price = 0
        if cart:
            products = Coffee.get_coffee_by_id(cart.keys())
            for product in products:
                quantity = cart.get(str(product.id), None)
                if quantity:
                    product_total = product.price * int(quantity)
                    data.append({
                        "product": product,
                        "quantity": quantity,
                        "total_price": product_total
                    })
                    total_price += product_total
        context = {"data": data, "total_price": total_price}
        return render(request, "store/cart.html", context)

    def post(self, request):
        cart = metadata['cart']
        user_id = metadata['user']
        # OrderItem
        # Order
        user = get_object_or_404(User, id = user_id)

        cart = json.loads(cart)
        order_items = []
        total_price = 0
        products = Coffee.get_coffee_by_id(cart.keys())
        for product in products:
            quantity = cart.get(str(product.id), None)
            if quantity:
                product_total = product.price * int(quantity)
                order_item = OrderItem.objects.create(
                    product = product,
                    price = product_total,
                    quantity = quantity,
                )
                order_items.append(order_item)
                total_price += product_total
        order = Order.objects.create(
            customer = user,
            price = total_price,
            address = '',
            phone = '',
            status = 'c',
        )
        for item in order_items:
            order.products.add(item)


